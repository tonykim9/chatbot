from django.shortcuts import render

# Create your views here.
import json
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from blueforge.apis.facebook import CreateFacebookApiClient, RequestDataFormat, Recipient, Message
verify_token = 'testest'
access_token = 'EAAITtzgkODYBAD1t99dVgFMbxZCNjZAuL1yyv2LeueZAPcUWM4PH7IwMEAFtz2xsLVTFeQeoEEoJeNM8ZCSHwzM9tKwgZAYZBPQxcAYOgsIiTBbZBB0cuioMV7DHgtaCvPmleYiNEJJGwEQP5uszu2ZBcXTh5eZCNq2VU66QR1fdXopxyZAkAcqcZBd'

req=CreateFacebookApiClient(access_token=access_token)

@csrf_exempt


def web_hook(request):
    print(request)
    if request.method == 'GET':
        if request.GET.get('hub.mode') == 'subscribe' and request.GET.get('hub.verify_token') == verify_token:
            return HttpResponse(request.GET.get('hub.challenge'))
    elif request.method == 'POST':
        print(request.body)
        message_entries= json.loads(request.body.decode('UTF-8'))['entry']
        for data in message_entries:
            for message in data['messaging']:
                req.send_message(RequestDataFormat(recipient=Recipient(recipient_id=message['sender']['id']), message=Message(text=message['message']['text'])))

                message_entries[0]['messaging'][0]['message']['text']
        return JsonResponse(data)
    return HttpResponse('Failed to request', status=404)