from django.apps import AppConfig


class FacebookConfig(AppConfig):
    name = 'facebook'
